var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var bodyParser = require('body-parser');
var app = express();

app.use(bodyParser.json());
app.use(express.urlencoded());

app.get('/', function (req, res) {
  console.log(__dirname + '/public/index.html')
  res.sendFile(path.join(__dirname + '/public/index.html'));
});

app.get('/bootstrap', function (req, res) {

  res.sendFile(path.join(__dirname + '/public/bootstrapform.html'));
});

app.post('/', function (req, res, next) {
  console.log(JSON.stringify(req.body))
  res.send(JSON.stringify(req.body));
});

app.post('/bootstrap', function (req, res, next) {
  console.log(JSON.stringify(req.body))
  res.send(JSON.stringify(req.body));
});
app.listen(3001);
module.exports = app;
